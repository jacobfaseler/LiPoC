/*
 * heartbeat.h
 *
 *  Created on: Feb 13, 2022
 *      Author: JacobFaseler
 */

/* Driver Header Files */
#include <ti/drivers/GPIO.h>

/* POSIX Header files */
#include <pthread.h>

#ifndef HEARTBEAT_H_
#define HEARTBEAT_H_





#endif /* HEARTBEAT_H_ */
