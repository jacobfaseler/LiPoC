/*
 * mem_man_tools.h
 *
 *  Created on: Feb 19, 2022
 *      Author: JacobFaseler
 */

#ifndef DEPRECATED_MEM_MAN_TOOLS_H_
#define DEPRECATED_MEM_MAN_TOOLS_H_

void sram_wipe ();



#endif /* DEPRECATED_MEM_MAN_TOOLS_H_ */
